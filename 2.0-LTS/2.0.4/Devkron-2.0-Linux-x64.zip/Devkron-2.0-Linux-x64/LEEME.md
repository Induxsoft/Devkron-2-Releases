# Devkron 2.0 para Linux x64 (2.0.4 LTS)

Distribución "pura": se descomprime en una carpeta y se configura a mano. No instala servicios ni toca el sistema.
El motor trae su propio .NET; no requiere instalar nada más.

## Qué trae

- `dkl`: motor de Devkron (consola y FastCGI con `dkl -fastcgi`), adaptadores MySQL, SQL Server, PostgreSQL y
  Firebird, y validación de licencia.
- Bibliotecas y marcos: encabezados `.dkh` (functions, serialize, dbr, webcl, threads, http, url, zip, time, text,
  hash, oauth, fs, log, listx, jsonx, env y edge), `Devkron.Ext.*.dll`, `dkl-web` (fso, crudl, plantillas) y el
  controlador `fastcgi/`.
- `SQLDic/` y `tools/dbrepo/`: diccionarios de consultas y herramienta para crear y administrar repositorios de
  conexiones en base de datos.
- `tools/dklwebsvr/`: servidor web HTTP/HTTPS para la FastCGI de Devkron (1.1.0: varios demonios por sitio,
  Let's Encrypt y gzip).
- `tools/w3se/`: puente de conexiones SSE y WebSocket.
- `tools/httptn/`: túnel HTTP inverso (servidor y agente en el mismo ejecutable).
- Configuraciones solo como ejemplo (`*.example`): nada viene activado.
- `license.txt` (Devkron), `NOTICE.txt` (terceros), `manifest.json` (versión y commit de cada componente).

Requiere una licencia de Devkron 2.0 (las de 1.x no sirven); sin ella funciona en modo demostración.

## Novedades de 2.0.4

- Corrige una regresión de 2.0.3: una referencia que nació nula (`ref x = @null`, o una búsqueda o expresión nula) y
  que después se apunta a otra con `ref x:y` quedaba nula desde la segunda llamada a la función, y el objeto de `y`
  (por ejemplo, el parámetro `&` de quien llama) se perdía. `ref x:y` vuelve a funcionar como en 1.x y `@null` sigue
  sin ocuparse.
- `ref x:y` cuando `x` ya apunta al mismo objeto que `y` ya no deja nulas a las dos.
- La tabla de objetos ya no crece con cada `ref r = <objeto nuevo>` en un ciclo (menos memoria en procesos largos).
- `list.add(l, valor)` con una cadena (aunque sea numérica, `"3"`) o con un número con decimales agrega el valor; antes
  podía agregar un objeto cualquiera del programa. Para agregar números enteros, use `list.addnum`.

## Novedades de 2.0.3 (incluidas)

- Caché del árbol en FastCGI con varios sitios (raíces multiinquilino): el árbol analizado de un archivo se guarda
  una sola vez aunque lo usen muchos sitios, y la caché tiene un tope de memoria (512 MB por omisión,
  `"tree_cache_mb"` en `fastcgi.json` o `DEVKRON_TREE_CACHE_MB`) con desalojo de lo menos usado.
- Crear un objeto sobre una referencia nula (flecha, `new`, `using`, bloque `$$`) ya no ocupa la ranura de `@null`:
  `@null` y las búsquedas fallidas siguen siendo nulas en todo el programa.

## Novedades de 2.0.2 (incluidas)

- Repositorios de conexiones en base de datos seguros con varios hilos (FastCGI), con reconexión y caché acotada.
- `connections.xml` se vuelve a leer si una conexión local falla y el archivo cambió (sin reiniciar).
- La pila de excepciones atrapadas guarda las 100 más recientes (antes crecía sin límite).

## Documentación

- Descargas y contenido: https://docs.induxsoft.net/es/devkron/2.0/instalacion/descargas.md
- Instalación en Linux: https://docs.induxsoft.net/es/devkron/2.0/instalacion/linux.md
- Licencia: https://docs.induxsoft.net/es/devkron/2.0/instalacion/licencia.md
- Repositorios de conexiones: https://docs.induxsoft.net/es/devkron/2.0/instalacion/repositorio-conexiones.md
- Novedades: https://docs.induxsoft.net/es/devkron/2.0/introduccion/novedades.md
- dklwebsvr: https://docs.induxsoft.net/es/devkron/2.0/instalacion/dklwebsvr.md
- w3se: https://docs.induxsoft.net/es/productos/tools/w3se/
- httptn: https://docs.induxsoft.net/es/productos/tools/httptn/
- Devkron: https://docs.induxsoft.net/es/devkron/
