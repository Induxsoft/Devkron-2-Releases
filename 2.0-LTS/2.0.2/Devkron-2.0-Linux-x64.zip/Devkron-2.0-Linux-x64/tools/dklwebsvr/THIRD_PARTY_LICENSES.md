# Licencias de terceros

dklwebsvr incluye en su ejecutable código de los siguientes módulos del proyecto Go (vendorizados en `vendor/`).
Los tres usan la misma licencia BSD de 3 cláusulas, reproducida abajo; `golang.org/x/crypto` trae además la concesión
de patentes de Google (`vendor/golang.org/x/crypto/PATENTS`).

| Módulo | Versión | Paquetes usados | Para qué |
|---|---|---|---|
| `golang.org/x/crypto` | v0.48.0 | `acme`, `acme/autocert` | Certificados automáticos por ACME (Let's Encrypt) |
| `golang.org/x/net` | v0.49.0 | `idna` | Requerido por `autocert` para nombres de dominio internacionales |
| `golang.org/x/text` | v0.34.0 | `secure/bidirule`, `transform`, `unicode/bidi`, `unicode/norm` | Requerido por `idna` |

Las pruebas usan además una copia sin cambios de `golang.org/x/crypto/acme/autocert/internal/acmetest`
(`internal/acmetest`), bajo la misma licencia; no forma parte del ejecutable.

Quien distribuya `dklwebsvr` (binario o código) debe incluir este archivo.

---

Copyright 2009 The Go Authors.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

   * Redistributions of source code must retain the above copyright
notice, this list of conditions and the following disclaimer.
   * Redistributions in binary form must reproduce the above
copyright notice, this list of conditions and the following disclaimer
in the documentation and/or other materials provided with the
distribution.
   * Neither the name of Google LLC nor the names of its
contributors may be used to endorse or promote products derived from
this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
