# Devkron 2.0 para Windows x64 (2.0.1 LTS)

Distribución "pura": se descomprime en una carpeta y se configura a mano. No instala servicios ni toca el sistema.
El motor trae su propio .NET; no requiere instalar nada más.

## Qué trae

- `dkl.exe`: motor de Devkron (consola y FastCGI con `dkl -fastcgi`), adaptadores MySQL, SQL Server, PostgreSQL y
  Firebird, y validación de licencia.
- Bibliotecas y marcos: encabezados `.dkh` (functions, serialize, dbr, webcl, threads, http, url, zip, time, text,
  hash, oauth, fs, log), `Devkron.Ext.*.dll`, `dkl-web` (fso, crudl, plantillas) y el controlador `fastcgi\`.
- `tools\dklwebsvr\`: servidor web HTTP/HTTPS para la FastCGI de Devkron.
- `tools\iis2dkl\`: puente FastCGI para publicar Devkron en IIS 10.
- `tools\w3se\`: puente de conexiones SSE y WebSocket.
- `tools\httptn\`: túnel HTTP inverso (servidor y agente en el mismo ejecutable).
- Configuraciones solo como ejemplo (`*.example`): nada viene activado.
- `license.txt` (Devkron), `NOTICE.txt` (terceros), `manifest.json` (versión y commit de cada componente).

Requiere una licencia de Devkron 2.0 (las de 1.x no sirven); sin ella funciona en modo demostración.

## Documentación

- Descargas y contenido: https://docs.induxsoft.net/es/devkron/2.0/instalacion/descargas.md
- Instalación en Windows: https://docs.induxsoft.net/es/devkron/2.0/instalacion/windows.md
- Licencia: https://docs.induxsoft.net/es/devkron/2.0/instalacion/licencia.md
- dklwebsvr: https://docs.induxsoft.net/es/devkron/2.0/instalacion/dklwebsvr.md
- IIS (iis2dkl): https://docs.induxsoft.net/es/devkron/2.0/instalacion/iis.md
- w3se: https://docs.induxsoft.net/es/productos/tools/w3se/
- httptn: https://docs.induxsoft.net/es/productos/tools/httptn/
- Devkron: https://docs.induxsoft.net/es/devkron/
