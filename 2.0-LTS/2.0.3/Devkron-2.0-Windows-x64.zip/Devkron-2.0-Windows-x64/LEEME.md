# Devkron 2.0 para Windows x64 (2.0.3 LTS)

Distribución "pura": se descomprime en una carpeta y se configura a mano. No instala servicios ni toca el sistema.
El motor trae su propio .NET; no requiere instalar nada más.

## Qué trae

- `dkl.exe`: motor de Devkron (consola y FastCGI con `dkl -fastcgi`), adaptadores MySQL, SQL Server, PostgreSQL y
  Firebird, y validación de licencia.
- Bibliotecas y marcos: encabezados `.dkh` (functions, serialize, dbr, webcl, threads, http, url, zip, time, text,
  hash, oauth, fs, log, listx, jsonx, env y edge), `Devkron.Ext.*.dll`, `dkl-web` (fso, crudl, plantillas) y el
  controlador `fastcgi\`.
- `SQLDic\` y `tools\dbrepo\`: diccionarios de consultas y herramienta para crear y administrar repositorios de
  conexiones en base de datos.
- `tools\dklwebsvr\`: servidor web HTTP/HTTPS para la FastCGI de Devkron (1.1.0: varios demonios por sitio,
  Let's Encrypt, gzip y servicio de Windows).
- `tools\iis2dkl\`: puente FastCGI para publicar Devkron en IIS 10.
- `tools\w3se\`: puente de conexiones SSE y WebSocket.
- `tools\httptn\`: túnel HTTP inverso (servidor y agente en el mismo ejecutable).
- Configuraciones solo como ejemplo (`*.example`): nada viene activado.
- `license.txt` (Devkron), `NOTICE.txt` (terceros), `manifest.json` (versión y commit de cada componente).

Requiere una licencia de Devkron 2.0 (las de 1.x no sirven); sin ella funciona en modo demostración.

## Novedades de 2.0.3

- Caché del árbol en FastCGI con varios sitios (raíces multiinquilino): el árbol analizado de un archivo se guarda
  una sola vez aunque lo usen muchos sitios, y la caché tiene un tope de memoria (512 MB por omisión,
  `"tree_cache_mb"` en `fastcgi.json` o `DEVKRON_TREE_CACHE_MB`) con desalojo de lo menos usado.
- Crear un objeto sobre una referencia nula (flecha, `new`, `using`, bloque `$$`) ya no ocupa la ranura de `@null`:
  `@null` y las búsquedas fallidas siguen siendo nulas en todo el programa.

## Novedades de 2.0.2 (incluidas)

- Repositorios de conexiones en base de datos seguros con varios hilos (FastCGI), con reconexión y caché acotada.
- `connections.xml` se vuelve a leer si una conexión local falla y el archivo cambió (sin reiniciar).
- La pila de excepciones atrapadas guarda las 100 más recientes (antes crecía sin límite).

## Documentación

- Descargas y contenido: https://docs.induxsoft.net/es/devkron/2.0/instalacion/descargas.md
- Instalación en Windows: https://docs.induxsoft.net/es/devkron/2.0/instalacion/windows.md
- Licencia: https://docs.induxsoft.net/es/devkron/2.0/instalacion/licencia.md
- Repositorios de conexiones: https://docs.induxsoft.net/es/devkron/2.0/instalacion/repositorio-conexiones.md
- Novedades: https://docs.induxsoft.net/es/devkron/2.0/introduccion/novedades.md
- dklwebsvr: https://docs.induxsoft.net/es/devkron/2.0/instalacion/dklwebsvr.md
- IIS (iis2dkl): https://docs.induxsoft.net/es/devkron/2.0/instalacion/iis.md
- w3se: https://docs.induxsoft.net/es/productos/tools/w3se/
- httptn: https://docs.induxsoft.net/es/productos/tools/httptn/
- Devkron: https://docs.induxsoft.net/es/devkron/
