# Devkron Edge (dkle) 2.0.1 para Windows x64

Runtime del lenguaje Devkron (DKL) para microservicios y conectores entre API HTTP: un solo ejecutable, sin
dependencias, con su propio servidor HTTP/HTTPS (y FastCGI) y cambios en caliente. Ejecuta los mismos programas
DKL que Devkron 2.0 con la biblioteca Edge integrada; no tiene bases de datos, sistema de archivos ni interop.

`dkle` es gratuito: no requiere licencia.

## Qué trae

- `dkle.exe`: el ejecutable (motor, biblioteca Edge, servidor HTTP/HTTPS/FastCGI y herramientas `run` y `check`).
- `dkle.json.example`: configuración del servidor, solo como ejemplo.
- `ejemplo/`: un sitio listo para probar (`hola.localhost`), con su configuración.
- `NOTICE.txt` y `licencias/`: avisos y licencias de los componentes de terceros.

## Probarlo en un minuto

```
cd dkle-2.0.1-Windows-x64/ejemplo
..\dkle.exe check --root .
..\dkle.exe run --root . GET /hola
..\dkle.exe serve -config dkle.json        # http://127.0.0.1:8080, sitio hola.localhost
curl -H "Host: hola.localhost" http://127.0.0.1:8080/hola
```

## Documentación

- Devkron Edge: https://docs.induxsoft.net/es/devkron/2.0/dkle/
- Instalación: https://docs.induxsoft.net/es/devkron/2.0/dkle/instalacion.md
- Configuración: https://docs.induxsoft.net/es/devkron/2.0/dkle/configuracion.md
