# dkl-debug

Depurador del lenguaje Devkron, o simplemente DKL. Es un ejecutable aparte (`dkl-debug`) que corre los programas con
el **mismo motor** de la distribución, sin modificarlo, y permite:

- detenerse en puntos de interrupción por línea (con condición o como mensaje de registro);
- avanzar paso a paso: entrar, saltar y salir de funciones;
- ver la pila de llamadas, las variables locales, las globales `@`, la tabla de objetos y los alias de un bloque `go`;
- expandir registros y listas;
- evaluar expresiones DKL en el marco seleccionado (consola de depuración, inspección y al pasar el cursor);
- detenerse en las excepciones no manejadas (o en todas);
- revisar la sintaxis sin ejecutar, con la **línea real** del error (`--check`).

Habla Debug Adapter Protocol (DAP), así que funciona con la extensión Devkron de VS Code y de Cursor.

## Instalación

1. Descargue el zip de su sistema: `dkl-debug-<versión>-linux-x64.zip`, `-linux-arm64.zip` o `-win-x64.zip`.
2. Descomprímalo en cualquier carpeta, por ejemplo `/opt/dkl-debug` o `C:\dkl-debug`.
3. Agregue esa carpeta al `PATH`, o indique la ruta del ejecutable en la extensión (ajuste `devkron.debuggerPath`).

El zip es autocontenido: trae el motor compilado del mismo commit que la distribución de Devkron, el runtime de .NET,
las bibliotecas estándar (`Devkron.Ext.*`, dbr y los adaptadores de base de datos) y los `.dkh` oficiales. No requiere
instalar .NET ni Devkron.

Ejecute siempre `dkl-debug` (o `dkl-debug.exe`) desde la carpeta descomprimida, no con `dotnet dkl-debug.dll`:
`_import_library` busca las bibliotecas en la carpeta del ejecutable.

Compruebe la instalación:

```bash
dkl-debug --version
```

## Uso con VS Code o Cursor

Con la extensión Devkron instalada, cree `.vscode/launch.json`:

```json
{
  "version": "0.2.0",
  "configurations": [
    {
      "type": "devkron",
      "request": "launch",
      "name": "Depurar programa DKL",
      "program": "${file}",
      "args": ["nombre=Ana", "modo=prueba"],
      "cwd": "${fileDirname}",
      "stopOnEntry": false
    }
  ]
}
```

| Atributo | Obligatorio | Descripción |
|---|---|---|
| `program` | sí | Ruta del `.dkl` |
| `args` | no | Argumentos del programa, como en `dkl programa.dkl a=1 b=2` |
| `cwd` | no | Carpeta de trabajo (por omisión, la del programa) |
| `stopOnEntry` | no | Detenerse en la primera sentencia (por omisión `false`) |
| `devkronRoot` | no | Raíz de una instalación de Devkron para buscar `.dkh` o marcos adicionales |
| `env` | no | Variables de entorno del programa |

La extensión lanza `dkl-debug --dap`. Los filtros de excepciones son «Todas las excepciones» y «Excepciones no
manejadas» (activo por omisión).

## Modos de línea de comandos

```bash
dkl-debug --dap                                   # adaptador DAP por stdin/stdout
dkl-debug --check programa.dkl [--json] [--root <dir>]
dkl-debug programa.dkl [--root <dir>] [--break archivo:línea ...] [--stop-on-entry] [-- args del programa]
dkl-debug --version
```

### `--check`

Analiza sin ejecutar y reporta los errores de sintaxis con la línea real. Con `--json` imprime un arreglo en una sola
línea (vacío si no hay errores); el código de salida es 0 sin errores y 1 con errores:

```json
[{"file":"/ruta/a.dkl","line":12,"column":5,"code":100,"severity":"error","message":"Símbolo no esperado"}]
```

Revisa dos cosas:

1. El análisis del motor (lo mismo que `dkl programa.dkl -parse`), con la línea corregida. El `[Ln= n]` del motor está
   desfasado (líneas en blanco en archivos LF, comentarios de bloque, sentencias con bloque); `dkl-debug` cuenta los
   fines de línea igual que el analizador para obtener la línea real. También ubica el `#include` que no existe, el
   inicio de una cadena sin cerrar y los errores dentro de bloques `$$`.
2. Las expresiones de las sentencias (`if`, `while`, `repeat`, asignaciones, `do`, `return`...): el motor solo las
   analiza al ejecutarlas; aquí se pasan por la misma gramática para avisar antes (por ejemplo, un paréntesis sin cerrar).

### Modo consola

Ejecuta el programa como `dkl programa.dkl args -hide-log` y en cada punto de interrupción imprime en stderr la
posición real, la pila y las variables locales; luego sigue. Útil para pruebas y para ver un recorrido rápido:

```bash
dkl-debug t30.dkl --break t30.dkl:21 --break 17
```

```
  >> PAUSA (breakpoint) en t30.dkl:21:9  [dkli-let]  | total = total + doble(v)
     en (principal) (t30.dkl:21)
       total = 0  (número)
       l = [3 elementos]  (ref lista)
       v = 3  (alias de value (go): número)
```

Otras opciones: `--break-all-exceptions` (detenerse también en las manejadas) y `--no-stop` (sin pausas: solo ejecuta).

## Limitaciones

- **Sin FastCGI todavía.** Depura programas de consola. La depuración de peticiones web (`dkl-debug -fastcgi`, una
  petición a la vez) es la fase siguiente.
- **Paquetes cifrados:** no se depuran. Se ejecutan como caja negra; sus líneas no admiten puntos de interrupción.
- **Compilación nativa apagada:** ese camino no pasa por el gancho de cada sentencia; el depurador siempre interpreta
  (la caché del árbol también se apaga). La salida del programa es la misma.
- **Mismo commit que la distribución:** `dkl-debug` reemplaza en memoria un método interno del motor; debe usarse con
  la distribución que se compiló del mismo commit (`dkl-debug --version` lo indica).
- **Un hilo:** solo se depura el hilo principal; lo que corre en `threads.*` se ejecuta sin detenerse.
- **Salida del programa:** la salida del programa llega como la produce el motor; lo que el motor arma en búfer (el
  documento de salida) aparece al terminar, igual que con `dkl`.
- **Bloques `go`:** el código del bloque corre en el marco de quien llama y ve los alias (aparecen en «Locales»); la
  función que lo incorpora (por ejemplo `foreach.lnum`) no aparece en la pila mientras corre el bloque.
- **Excepciones:** las no manejadas detienen en la sentencia que falló, cuando la ejecución ya terminó: se ven la pila y
  las variables de ese momento, pero «evaluar» solo admite nombres de variables. Con «Todas las excepciones», las
  manejadas detienen al empezar su bloque `exception` (el texto indica dónde se lanzó).
- El paso a paso no entra en los `.dkh` oficiales (están junto a `dkl-debug` o en `devkronRoot`) ni se detiene en las
  declaraciones `program`/`module`; los puntos de interrupción sí funcionan ahí.
- Si dos archivos incluidos se llaman igual en carpetas distintas, el motor solo guarda el nombre: se usa el primero.

## Cómo funciona (sin tocar el motor)

- `dkl-debug` referencia los proyectos del motor de este repositorio (`src/`) como IL normal, sin ReadyToRun, y no
  modifica su código, sus proyectos ni la solución.
- Al arrancar reemplaza en memoria (Harmony 2.4) **un solo método**: `Devkron.Interpreter.stepbystep(Element, ContextBlock)`,
  el gancho que el intérprete ya llama antes de cada sentencia cuando `Program.settings.StepByStep` está activo
  (en `dkl` normal no se activa y no cuesta nada). El reemplazo decide si detenerse.
- **Posiciones exactas:** el motor guarda en cada sentencia el índice del token donde empieza dentro de la lista de
  tokens del bloque que la contiene (los bloques anidados son sublistas de la misma lista del archivo), y cada token
  conserva su desplazamiento real. Al cargar, `dkl-debug` analiza el programa con el mismo analizador y arma un mapa
  `archivo|línea del motor|posición|nombre → línea y columna reales`. Algunos elementos (`else`, `default`, `$$`, los
  elementos declarativos) guardan directamente el desplazamiento en caracteres. Los archivos que aparecen en ejecución
  (sentencia `include`, `runscript`) se mapean al vuelo. Validado sobre las pruebas de conformidad y la distribución:
  todas las sentencias con su línea y columna exactas (`tests/run.sh`, prueba «posiciones»).
- **Pila:** la cadena de `ContextBlock.ParentContext`; para cada contexto se guarda la última sentencia que pasó por
  el gancho (posición del marco) y el nombre de la función sale del mapa.
- **Variables:** `context.Variables` (locales), `context.GlobalVars` (globales), la tabla de objetos y los alias de
  `go` (`MapVars`/`MapSource`, la «variable mapeada» que no está en `Variables`). **Evaluar** usa `context.Eval`.
- **Excepciones:** se observan con el evento `FirstChanceException` del proceso (sin parches adicionales) para guardar
  la pila y las variables de la sentencia que falló; las manejadas se reconocen cuando el motor las registra en su pila
  de excepciones.
- El motor corre en un hilo propio; el lector DAP en otro. La salida del programa se envía como eventos `output`
  (stdout real reservado para el protocolo).

## Desarrollo

```bash
cd tools/dkl-debug
dotnet build src/dkl-debug.csproj -c Release   # ejecutable en src/bin/Release/net10.0/dkl-debug
tests/run.sh                                    # todas las pruebas (≈3 min); --rapido omite la comparación con dkl
./publish.sh                                    # zips en dist/ (linux-x64, linux-arm64, win-x64)
```

`tests/run.sh` comprueba: (a) posiciones exactas en todo el corpus, (b) `--check --json` con errores conocidos, (c) un
cliente DAP de prueba (Python 3, sin dependencias) y (d) que el modo consola dé la misma salida que `dkl` en las pruebas
de conformidad. Con `DKL_DEBUG=<ruta>` prueba un ejecutable ya publicado.
